import Link from "next/link"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screen-YZQO78Vz1qYL6P7ambsrOADXlhitxQ.png"
                alt="Khalid Fabrics Logo"
                width={50}
                height={50}
                className="object-contain"
              />
              <span className="text-white font-bold text-xl">KHALID FABRICS</span>
            </Link>
            <p className="text-white/70 mb-4">
              Home of quality fabrics for all your needs. From traditional to modern designs, we offer the finest
              quality materials for your clothing and home decor.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-amber-400">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-white/70 hover:text-amber-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="#about" className="text-white/70 hover:text-amber-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#products" className="text-white/70 hover:text-amber-400 transition-colors">
                  Products
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-white/70 hover:text-amber-400 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-white/70 hover:text-amber-400 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-amber-400">Products</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-white/70 hover:text-amber-400 transition-colors">
                  Cotton Fabrics
                </Link>
              </li>
              <li>
                <Link href="#" className="text-white/70 hover:text-amber-400 transition-colors">
                  Silk & Satin
                </Link>
              </li>
              <li>
                <Link href="#" className="text-white/70 hover:text-amber-400 transition-colors">
                  Traditional Prints
                </Link>
              </li>
              <li>
                <Link href="#" className="text-white/70 hover:text-amber-400 transition-colors">
                  Linen & Wool
                </Link>
              </li>
              <li>
                <Link href="#" className="text-white/70 hover:text-amber-400 transition-colors">
                  Home Decor Fabrics
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-amber-400">Contact Info</h3>
            <ul className="space-y-2">
              <li className="text-white/70">123 Fabric Street, Accra, Ghana</li>
              <li className="text-white/70">Phone: 0244845590, 0543081925</li>
              <li className="text-white/70">Email: nbt2124@gmail.com</li>
              <li className="text-white/70">Hours: Mon-Fri 8AM-6PM, Sat 9AM-4PM</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/50 text-sm">
            &copy; {new Date().getFullYear()} Khalid Fabrics. All rights reserved.
          </p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="#" className="text-white/50 hover:text-amber-400 transition-colors text-sm">
              Privacy Policy
            </Link>
            <Link href="#" className="text-white/50 hover:text-amber-400 transition-colors text-sm">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

