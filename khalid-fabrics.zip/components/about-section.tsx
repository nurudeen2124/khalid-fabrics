import Image from "next/image"
import { CheckCircle } from "lucide-react"

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-neutral-900">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">About Khalid Fabrics</h2>
            <div className="w-24 h-1 bg-amber-500 mb-6"></div>
            <p className="text-white/80 mb-6">
              Founded in 2010, Khalid Fabrics has been a trusted name in the textile industry, providing high-quality
              fabrics to customers across Ghana and beyond. Our commitment to excellence and customer satisfaction has
              made us a preferred choice for both individual customers and businesses.
            </p>
            <p className="text-white/80 mb-8">
              We source our fabrics from the finest mills around the world, ensuring that every yard of fabric that
              leaves our store meets the highest standards of quality. Whether you're looking for traditional African
              prints, luxury silks, or everyday cotton, we have something for everyone.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="text-amber-500 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-white font-medium">Premium Quality</h3>
                  <p className="text-white/70 text-sm">Only the finest materials</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-amber-500 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-white font-medium">Wide Selection</h3>
                  <p className="text-white/70 text-sm">Hundreds of fabrics to choose from</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-amber-500 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-white font-medium">Expert Advice</h3>
                  <p className="text-white/70 text-sm">Guidance from textile professionals</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-amber-500 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-white font-medium">Custom Orders</h3>
                  <p className="text-white/70 text-sm">Tailored to your specific needs</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative h-[500px] rounded-lg overflow-hidden shadow-xl shadow-amber-500/10">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/i.jpg-GJ6fRsdor0jM6UstW4EaitsgCGZX7W.jpeg"
                alt="Khalid Fabrics Quality"
                fill
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-amber-500 rounded-lg -z-10"></div>
            <div className="absolute -top-6 -right-6 w-48 h-48 border-2 border-amber-500 rounded-lg -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  )
}

