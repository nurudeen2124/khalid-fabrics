"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
        isScrolled ? "bg-black/90 backdrop-blur-sm py-2" : "bg-black/70 py-4",
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screen-YZQO78Vz1qYL6P7ambsrOADXlhitxQ.png"
              alt="Khalid Fabrics Logo"
              width={50}
              height={50}
              className="object-contain"
            />
            <span className="text-white font-bold text-xl hidden sm:inline-block">KHALID FABRICS</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-gold-300 transition-colors">
              Home
            </Link>
            <Link href="#about" className="text-white hover:text-gold-300 transition-colors">
              About
            </Link>
            <Link href="#products" className="text-white hover:text-gold-300 transition-colors">
              Products
            </Link>
            <Link href="#services" className="text-white hover:text-gold-300 transition-colors">
              Services
            </Link>
            <Link href="#contact" className="text-white hover:text-gold-300 transition-colors">
              Contact
            </Link>
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">Shop Now</Button>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-black/95 absolute top-full left-0 w-full">
          <div className="flex flex-col space-y-4 p-4">
            <Link href="/" className="text-white hover:text-amber-400 py-2" onClick={() => setIsOpen(false)}>
              Home
            </Link>
            <Link href="#about" className="text-white hover:text-amber-400 py-2" onClick={() => setIsOpen(false)}>
              About
            </Link>
            <Link href="#products" className="text-white hover:text-amber-400 py-2" onClick={() => setIsOpen(false)}>
              Products
            </Link>
            <Link href="#services" className="text-white hover:text-amber-400 py-2" onClick={() => setIsOpen(false)}>
              Services
            </Link>
            <Link href="#contact" className="text-white hover:text-amber-400 py-2" onClick={() => setIsOpen(false)}>
              Contact
            </Link>
            <Button className="bg-amber-500 hover:bg-amber-600 text-black w-full">Shop Now</Button>
          </div>
        </div>
      )}
    </nav>
  )
}

