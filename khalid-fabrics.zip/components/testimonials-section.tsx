"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Fashion Designer",
    content:
      "Khalid Fabrics has been my go-to source for premium materials for my fashion line. Their quality is unmatched and their customer service is exceptional.",
    rating: 5,
  },
  {
    id: 2,
    name: "Michael Osei",
    role: "Interior Decorator",
    content:
      "I've been working with Khalid Fabrics for over 3 years now, and they never disappoint. Their selection of upholstery fabrics is extensive and of the highest quality.",
    rating: 5,
  },
  {
    id: 3,
    name: "Amina Mensah",
    role: "Bridal Shop Owner",
    content:
      "The silk and lace fabrics I purchase from Khalid Fabrics make my bridal gowns stand out. My customers always comment on the beautiful quality of the materials.",
    rating: 4,
  },
  {
    id: 4,
    name: "David Adu",
    role: "Tailor",
    content:
      "As a professional tailor, I need reliable suppliers. Khalid Fabrics delivers consistently excellent materials that make my job easier and my clients happier.",
    rating: 5,
  },
]

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const itemsPerPage = 3
  const totalPages = Math.ceil(testimonials.length / itemsPerPage)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + itemsPerPage >= testimonials.length ? 0 : prevIndex + itemsPerPage))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex - itemsPerPage < 0 ? Math.max(0, testimonials.length - itemsPerPage) : prevIndex - itemsPerPage,
    )
  }

  const visibleTestimonials = testimonials.slice(currentIndex, currentIndex + itemsPerPage)

  return (
    <section className="py-20 bg-neutral-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">What Our Customers Say</h2>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-6"></div>
          <p className="text-white/80 max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
        </div>

        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {visibleTestimonials.map((testimonial) => (
              <Card key={testimonial.id} className="bg-neutral-800 border-neutral-700">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < testimonial.rating ? "text-amber-400 fill-amber-400" : "text-gray-400"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-white/80 mb-6 italic">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <Avatar className="h-12 w-12 border-2 border-amber-500">
                      <AvatarFallback className="bg-amber-500/20 text-amber-500">
                        {testimonial.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="ml-4">
                      <h4 className="text-white font-medium">{testimonial.name}</h4>
                      <p className="text-white/60 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex justify-center mt-8 gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={prevSlide}
                className="border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-black"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={nextSlide}
                className="border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-black"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

