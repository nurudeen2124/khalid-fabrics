import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const products = [
  {
    id: 1,
    name: "Premium Cotton",
    description: "Soft and breathable cotton fabric for everyday wear",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/i.jpg-GJ6fRsdor0jM6UstW4EaitsgCGZX7W.jpeg",
    price: "₵75/yard",
  },
  {
    id: 2,
    name: "Luxury Silk",
    description: "Elegant silk fabric for special occasions",
    image: "/placeholder.svg?height=400&width=400",
    price: "₵150/yard",
  },
  {
    id: 3,
    name: "Traditional Kente",
    description: "Authentic Ghanaian Kente cloth with vibrant patterns",
    image: "/placeholder.svg?height=400&width=400",
    price: "₵120/yard",
  },
  {
    id: 4,
    name: "Modern Linen",
    description: "Durable linen fabric perfect for summer clothing",
    image: "/placeholder.svg?height=400&width=400",
    price: "₵95/yard",
  },
]

export default function FeaturedProducts() {
  return (
    <section id="products" className="py-20 bg-neutral-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Featured Fabrics</h2>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-6"></div>
          <p className="text-white/80 max-w-2xl mx-auto">
            Explore our collection of premium fabrics, carefully selected for quality and style
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Card
              key={product.id}
              className="bg-neutral-800 border-neutral-700 overflow-hidden hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300"
            >
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 hover:scale-105"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-white mb-2">{product.name}</h3>
                <p className="text-white/70 mb-4">{product.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-amber-400 font-medium">{product.price}</span>
                  <Button
                    variant="outline"
                    className="border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-black"
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button className="bg-amber-500 hover:bg-amber-600 text-black px-8 py-6 text-lg">View All Products</Button>
        </div>
      </div>
    </section>
  )
}

