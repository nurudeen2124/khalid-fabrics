"use client"

import { useState, useRef } from "react"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function VideoSection() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)
  const videoRef = useRef<HTMLVideoElement>(null)

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Experience Our Craftsmanship</h2>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-6"></div>
          <p className="text-white/80 max-w-2xl mx-auto">
            Watch how we create and source the finest fabrics for our customers
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative rounded-xl overflow-hidden shadow-2xl shadow-amber-500/10">
          <video
            ref={videoRef}
            className="w-full aspect-video object-cover"
            poster="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screen-YZQO78Vz1qYL6P7ambsrOADXlhitxQ.png"
            muted
            playsInline
          >
            <source
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/desw-3zosoYA37WHQlKY80sqRxAnvzejffJ.mp4"
              type="video/mp4"
            />
            Your browser does not support the video tag.
          </video>

          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-center justify-center">
            {!isPlaying && (
              <Button
                onClick={togglePlay}
                className="bg-amber-500/90 hover:bg-amber-500 text-black rounded-full w-16 h-16 flex items-center justify-center"
              >
                <Play size={24} fill="currentColor" />
              </Button>
            )}
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 flex items-center justify-between bg-gradient-to-t from-black to-transparent">
            <Button variant="ghost" size="icon" onClick={togglePlay} className="text-white hover:bg-white/20">
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </Button>

            <Button variant="ghost" size="icon" onClick={toggleMute} className="text-white hover:bg-white/20">
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

