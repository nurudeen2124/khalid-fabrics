import { Scissors, Truck, Palette, Users, MessageSquare, Clock } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    icon: <Scissors className="h-10 w-10 text-amber-500" />,
    title: "Custom Tailoring",
    description: "Get your fabrics tailored by our expert craftsmen to create the perfect garment for any occasion.",
  },
  {
    icon: <Truck className="h-10 w-10 text-amber-500" />,
    title: "Nationwide Delivery",
    description: "We deliver our fabrics to all regions in Ghana, ensuring you get your orders promptly and safely.",
  },
  {
    icon: <Palette className="h-10 w-10 text-amber-500" />,
    title: "Color Matching",
    description: "Our specialists can help you find the perfect color match for your existing fabrics or design ideas.",
  },
  {
    icon: <Users className="h-10 w-10 text-amber-500" />,
    title: "Bulk Orders",
    description: "Special pricing and handling for businesses and events requiring large quantities of fabric.",
  },
  {
    icon: <MessageSquare className="h-10 w-10 text-amber-500" />,
    title: "Consultation",
    description: "Get expert advice on fabric selection for your specific project needs from our experienced team.",
  },
  {
    icon: <Clock className="h-10 w-10 text-amber-500" />,
    title: "Express Service",
    description: "Need your fabrics urgently? Our express service ensures you get what you need when you need it.",
  },
]

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          <div className="w-24 h-1 bg-amber-500 mx-auto mb-6"></div>
          <p className="text-white/80 max-w-2xl mx-auto">We offer a range of services to meet all your fabric needs</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="bg-neutral-800 border-neutral-700 hover:border-amber-500/50 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                <p className="text-white/70">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

