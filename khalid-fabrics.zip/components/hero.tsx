import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screen-YZQO78Vz1qYL6P7ambsrOADXlhitxQ.png"
          alt="Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/70"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 z-10 text-center">
        <div className="max-w-3xl mx-auto">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screen-YZQO78Vz1qYL6P7ambsrOADXlhitxQ.png"
            alt="Khalid Fabrics Logo"
            width={200}
            height={200}
            className="mx-auto mb-8"
          />
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Welcome to <span className="text-amber-400">Khalid Fabrics</span>
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 italic">Home of Quality Fabrics</p>
          <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto">
            Discover our premium collection of fabrics for all your needs. From traditional to modern designs, we offer
            the finest quality materials for your clothing and home decor.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black text-lg px-8 py-6">Explore Collection</Button>
            <Button variant="outline" className="border-white text-white hover:bg-white/10 text-lg px-8 py-6">
              Contact Us
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

